﻿namespace Sigma.PerformanceMonitor.Store
{
    public class ServerProfile
    {
        public string Name { set; get; } = default;
        public string IP { set; get; } = default;
    }
}