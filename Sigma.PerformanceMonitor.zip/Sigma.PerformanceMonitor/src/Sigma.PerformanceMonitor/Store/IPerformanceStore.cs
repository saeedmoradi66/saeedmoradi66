﻿using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor.Store
{
    public interface IPerformanceStore
    {
        Task<Counter[]> GetActiveCountersAsync(string serverName, CancellationToken cancellationToken = default);
        Task<Counter> FetchActiveCounterAsync(string serverName,
                                              string counterName,
                                              string providerName,
                                              CancellationToken cancellationToken = default);
        Task SaveMetricAsync(Metric metric, CancellationToken cancellationToken = default);
    }
}