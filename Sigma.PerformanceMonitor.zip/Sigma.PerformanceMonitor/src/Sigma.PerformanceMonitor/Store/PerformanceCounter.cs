﻿namespace Sigma.PerformanceMonitor.Store
{
    public class PerformanceCounter
    {
        public string Name { set; get; } = default;
        public string CategoryName { set; get; } = default;
    }
}