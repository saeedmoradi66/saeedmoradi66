﻿namespace Sigma.PerformanceMonitor.Store
{
    public class PerformanceCounterCategory
    {
        public string Name { set; get; } = default;
    }
}