﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor.Scheduler
{
    public class RecurringJob : IRecurringJob
    {
        private readonly ConcurrentDictionary<string, (Func<Task> job, CancellationTokenSource cts)> _jobs = new ConcurrentDictionary<string, (Func<Task> job, CancellationTokenSource cts)>();
        private bool _disposed = false;
        public void Schedule(string name, Func<CancellationToken, Task> callback, TimeSpan dueTime, TimeSpan period)
        {
            var cts = new CancellationTokenSource();
            var jobRunner = CreateJobRunner(callback, dueTime, period, cts.Token);
            Task.Factory.StartNew(jobRunner, cts.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default).Unwrap();
            _jobs.AddOrUpdate(name, (jobRunner, cts), (key, old) => (jobRunner, cts));
        }
        public void Unschedule(string name)
        {
            if (_jobs.ContainsKey(name) && _jobs.TryGetValue(name, out (Func<Task> job, CancellationTokenSource cts) value))
            {
                value.cts.Cancel();
                _jobs.TryRemove(name, out _);
            }
        }
        private static Func<Task> CreateJobRunner(Func<CancellationToken, Task> callback, TimeSpan dueTime, TimeSpan period, CancellationToken cancellationToken)
            => async () =>
            {
                if (dueTime > TimeSpan.Zero)
                    await Task.Delay(dueTime, cancellationToken);
                while (!cancellationToken.IsCancellationRequested)
                {
                    try
                    {
                        await callback(cancellationToken);
                    }
                    finally
                    {
                        await Task.Delay(period, cancellationToken);
                    }
                }
            };
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!_jobs.IsEmpty)
            {
                foreach (var (_, cts) in _jobs.Values)
                {
                    cts.Cancel();
                    cts.Dispose();
                }
                _jobs.Clear();
            }
            _disposed = true;
        }
    }
}