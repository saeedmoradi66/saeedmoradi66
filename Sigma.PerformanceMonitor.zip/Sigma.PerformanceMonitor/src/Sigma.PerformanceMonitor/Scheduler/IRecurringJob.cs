﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor.Scheduler
{
    public interface IRecurringJob : IDisposable
    {
        void Schedule(string name, Func<CancellationToken, Task> callback, TimeSpan dueTime, TimeSpan period);
        void Unschedule(string name);
    }
}