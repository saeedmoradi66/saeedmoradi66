﻿using Sigma.PerformanceMonitor.Provider;
using Sigma.PerformanceMonitor.Store;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor
{
    public class CounterMetricCollector
    {
        private readonly Counter _counter;
        private readonly IPerformanceMetricProvider _provider;
        private readonly IPerformanceStore _store;
        public CounterMetricCollector(Counter counter,
                                      IPerformanceMetricProvider provider,
                                      IPerformanceStore store)
        {
            _counter = counter ?? throw new ArgumentNullException(nameof(counter));
            _provider = provider ?? throw new ArgumentNullException(nameof(provider));
            _store = store ?? throw new ArgumentNullException(nameof(store));
        }
        public string Name => _counter.Name;
        public string ProviderName => _counter.ProviderName;
        public string ServerName => _counter.Server;
        public int DueTimeInMilliseconds => _counter.DueTimeInMilliseconds;
        public int PeriodInMilliseconds => _counter.PeriodInMilliseconds;
        public async Task<Metric> Collect(CancellationToken cancellationToken = default)
        {
            var metricValue = await _provider.Get(_counter.Name, cancellationToken);
            Metric metric = new Metric(_counter, metricValue);
            return metric;
        }
        public bool IsAssignedBy(Counter counter)
            => string.Compare(this._counter.Name, counter.Name) == 0
            && string.Compare(this._counter.ProviderName, counter.ProviderName) == 0
            && string.Compare(this._counter.Server, counter.Server) == 0;
        public override string ToString() => $"{Name}-{ProviderName}-{ServerName}";
    }
}