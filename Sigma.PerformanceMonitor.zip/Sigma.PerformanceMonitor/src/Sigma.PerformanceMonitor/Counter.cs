﻿namespace Sigma.PerformanceMonitor
{
    public class Counter
    {
        public string Name { set; get; } = default;
        public string ProviderName { set; get; } = default;
        public string Server { set; get; } = default;
        public int DueTimeInMilliseconds { set; get; } = default;
        public int PeriodInMilliseconds { set; get; } = default;
        public double MetricValueThreshold { set; get; } = default;
        public bool IsEmailNotificationEnabled { set; get; } = false;
        public bool IsSMSNotificationEnabled { set; get; } = false;
        public override string ToString() => $"{Name} - {ProviderName} - {Server}";
    }
}