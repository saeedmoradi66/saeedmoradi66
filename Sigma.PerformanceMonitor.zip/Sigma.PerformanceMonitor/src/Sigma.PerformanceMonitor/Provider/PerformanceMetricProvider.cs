﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor.Provider
{
    public abstract class PerformanceMetricProvider : IPerformanceMetricProvider
    {
        private readonly PerformanceMetricProviderConfig _config;
        private readonly string[] _availableCounters;
        private DateTime _lastDate = DateTime.MinValue;
        private Dictionary<string, double> _lastValues = new Dictionary<string, double>();
        private readonly SemaphoreSlim _semaphor = new SemaphoreSlim(1, 1);
        public string Name => _config.Name;
        public Dictionary<string, string> CounterMappings => _config.CounterMappings;
        public string[] SupportedCounters => CounterMappings.Keys.ToArray();
        public PerformanceMetricProvider(PerformanceMetricProviderConfig config)
        {
            _config = config;
            _availableCounters = _config.CounterMappings.Values?.ToArray();
        }
        public async Task<MetricValue> Get(string counterName, CancellationToken cancellationToken)
        {
            if (!CounterMappings.TryGetValue(counterName, out var mappedCounterName))
                throw new InvalidOperationException($"No mapping exists for counter. (counterName: {counterName}, providerName: {Name})");

            await IfCacheExpiredgetNewMetrics(cancellationToken);
            if (_lastValues.TryGetValue(mappedCounterName, out var value))
                return new MetricValue(value, _lastDate);
            return MetricValue.Default(_lastDate);
        }
        private async Task IfCacheExpiredgetNewMetrics(CancellationToken cancellationToken)
        {
            await _semaphor.WaitAsync(cancellationToken);
            var cacheExpired = (DateTime.Now - _lastDate).TotalMilliseconds >= _config.CacheExpirationInMiliseconds;
            if (_config.CacheExpirationInMiliseconds == 0 || cacheExpired)
                (_lastDate, _lastValues) = await GetMetrics(_availableCounters, cancellationToken);
            _semaphor.Release();
        }
        public abstract Task<(DateTime date, Dictionary<string, double> values)> GetMetrics(string[] counterNames, CancellationToken cancellationToken);
    }
}