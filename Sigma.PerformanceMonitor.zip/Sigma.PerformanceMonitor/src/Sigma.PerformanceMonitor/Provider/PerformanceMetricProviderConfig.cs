﻿using System.Collections.Generic;

namespace Sigma.PerformanceMonitor.Provider
{
    public class PerformanceMetricProviderConfig
    {
        public string Name { set; get; } = default;
        public Dictionary<string, string> CounterMappings { set; get; } = default;
        // set zero to disable cache
        public int CacheExpirationInMiliseconds { set; get; }
    }
}