﻿using System.Linq;

namespace Sigma.PerformanceMonitor.Provider
{
    public class SqlServerPerformanceMetricProviderConfig : PerformanceMetricProviderConfig
    {
        public string ConnectionString { set; get; } = default;
        public string[] SupportedCounters => CounterMappings.Keys.ToArray();
    }
}