﻿namespace Sigma.PerformanceMonitor.Provider
{
    public abstract class SqlServerPerformanceMetricProvider : PerformanceMetricProvider
    {
        private readonly SqlServerPerformanceMetricProviderConfig _config;
        public SqlServerPerformanceMetricProvider(SqlServerPerformanceMetricProviderConfig config) : base(config)
        {
            _config = config;
        }
    }
}