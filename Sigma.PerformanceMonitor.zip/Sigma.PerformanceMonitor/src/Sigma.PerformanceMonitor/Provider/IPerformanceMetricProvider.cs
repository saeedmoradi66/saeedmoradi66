﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor.Provider
{
    public interface IPerformanceMetricProvider
    {
        string Name { get; }
        string[] SupportedCounters { get; }
        Dictionary<string, string> CounterMappings { get; }
        Task<MetricValue> Get(string counterName, CancellationToken cancellationToken);
    }
}