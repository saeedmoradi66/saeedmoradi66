﻿using System;

namespace Sigma.PerformanceMonitor
{
    public class Metric
    {
        public Counter Counter { get; }
        public double? Value { get; }
        public DateTime Date { get; }
        public Metric(Counter counter, double? value, DateTime date)
        {
            Counter = counter;
            Value = value;
            Date = date;
        }
        public Metric(Counter counter, MetricValue metricValue) : this(counter, metricValue.Value, metricValue.Date) { }
        public override string ToString()
            => $"{Counter} threshold is {Counter.MetricValueThreshold:#.###} value is {Value:#.###} at {Date:HH:mm:ss:fff}";
    }
    public class MetricValue
    {
        public double? Value { get; }
        public DateTime Date { get; }
        public MetricValue(double value, DateTime date)
        {
            Value = value;
            Date = date;
        }
        private MetricValue(DateTime date)
        {
            Value = null;
            Date = date;
        }
        public static MetricValue Default(DateTime date) => new MetricValue(date);
    }
}