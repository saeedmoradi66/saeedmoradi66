﻿using Microsoft.Extensions.Logging;
using Sigma.PerformanceMonitor.Notifier;
using Sigma.PerformanceMonitor.Provider;
using Sigma.PerformanceMonitor.Scheduler;
using Sigma.PerformanceMonitor.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor
{
    public class PerformanceScanner : IDisposable
    {
        private readonly PerformanceScannerConfig _config;
        private readonly IEnumerable<IPerformanceMetricProvider> _providers;
        private readonly IPerformanceStore _store;
        private readonly IRecurringJob _recurringJobs;
        private readonly INotifier _notifier;
        private readonly ILogger<PerformanceScanner> _logger;
        private readonly Dictionary<IPerformanceMetricProvider, IEnumerable<Counter>> _countersGroup = new Dictionary<IPerformanceMetricProvider, IEnumerable<Counter>>();
        private readonly List<CounterMetricCollector> _collectors = new List<CounterMetricCollector>();
        private readonly SemaphoreSlim _semaphor = new SemaphoreSlim(1, 1);
        private bool _isStarted = false;
        private bool _disposed = false;

        public PerformanceScanner(PerformanceScannerConfig config,
                                  IEnumerable<IPerformanceMetricProvider> providers,
                                  IPerformanceStore store,
                                  IRecurringJob recurringJobs,
                                  INotifier notifier,
                                  ILogger<PerformanceScanner> logger)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _providers = providers ?? throw new ArgumentNullException(nameof(providers));
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _recurringJobs = recurringJobs ?? throw new ArgumentNullException(nameof(recurringJobs));
            _notifier = notifier ?? throw new ArgumentNullException(nameof(notifier));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async System.Threading.Tasks.Task Start(CancellationToken cancellationToken = default)
        {
            _logger.LogDebug($"{CLASS_NAME} starting...");
            if (_disposed)
                throw new ObjectDisposedException(nameof(PerformanceScanner));
            await _semaphor.WaitAsync(cancellationToken);
            AssertIfIsRunning();
            if (_isStarted)
            {
                _semaphor.Release();
                _logger.LogDebug($"{CLASS_NAME} was started.");
                return;
            }
            _isStarted = true;
            await StartAll(cancellationToken);
            _semaphor.Release();
            _logger.LogDebug($"{CLASS_NAME} started.");
        }
        public async Task Stop(CancellationToken cancellationToken = default)
        {
            _logger.LogDebug($"{CLASS_NAME} stopping...");
            if (_disposed)
                throw new ObjectDisposedException(nameof(PerformanceScanner));
            await _semaphor.WaitAsync(cancellationToken);
            AssertIfNotStrated();
            if (IsRunning())
                StopAll();
            _semaphor.Release();
            _logger.LogDebug($"{CLASS_NAME} stopped.");
        }
        public async Task Stop(Counter counter, CancellationToken cancellationToken = default)
        {
            _logger.LogDebug("{} stopping counter ({})...", CLASS_NAME, counter);
            if (_disposed)
                throw new ObjectDisposedException(nameof(PerformanceScanner));
            await _semaphor.WaitAsync(cancellationToken);
            AssertIfNotStrated();
            if (!IsRunning())
            {
                _semaphor.Release();
                _logger.LogDebug("{} could not stop counter ({}), performance scanner did not running.", CLASS_NAME, counter);
                return;
            }
            StopCounter(counter);
            _logger.LogDebug("{} counter ({}) stopped.", CLASS_NAME, counter);
            _semaphor.Release();
        }
        public async Task Restart(CancellationToken cancellationToken = default)
        {
            _logger.LogDebug($"{CLASS_NAME} is restarting...");
            if (_disposed)
                throw new ObjectDisposedException(nameof(PerformanceScanner));
            await _semaphor.WaitAsync(cancellationToken);
            AssertIfNotStrated();
            if (IsRunning())
                StopAll();
            await StartAll(cancellationToken);
            _semaphor.Release();
            _logger.LogDebug($"{CLASS_NAME} restarted.");
        }
        public async Task Restart(Counter counter, CancellationToken cancellationToken = default)
        {
            _logger.LogDebug("{} restarting counter ({}) ...", CLASS_NAME, counter);
            if (_disposed)
                throw new ObjectDisposedException(nameof(PerformanceScanner));
            await _semaphor.WaitAsync(cancellationToken);
            AssertIfNotStrated();
            StopCounter(counter);
            _logger.LogDebug("{} restarting counter ({}), fetching new values...", CLASS_NAME, counter);
            counter = await _store.FetchActiveCounterAsync(_config.CurrentServerName, counter.Name, counter.ProviderName, cancellationToken);
            if (counter is null)
            {
                _semaphor.Release();
                _logger.LogWarning("{} restart failed, counter not found. ({})", CLASS_NAME, counter);
                throw new InvalidOperationException($"Counter does not exists. (counter: {counter})");
            }
            StartCounter(counter);
            _logger.LogDebug("{} counter ({}) restarted.", CLASS_NAME, counter);
            _semaphor.Release();
        }

        private async Task StartAll(CancellationToken cancellationToken = default)
        {
            if (IsRunning())
                return;
            await Init(cancellationToken);
        }
        private void StopAll()
        {
            if (_isStarted)
                foreach (var collector in _collectors)
                    _recurringJobs.Unschedule(collector.ToString());
            _collectors.Clear();
        }
        private void StopCounter(Counter counter)
        {
            var collector = _collectors.FirstOrDefault(collectorItem => collectorItem.IsAssignedBy(counter));
            if (collector is null)
            {
                _logger.LogWarning("Counter does not exists. (coutner: {})", counter);
                return;
            }

            _recurringJobs.Unschedule(collector.ToString());
            _collectors.Remove(collector);
        }
        private void StartCounter(Counter counter)
        {
            if (string.Compare(counter.Server, _config.CurrentServerName) != 0)
            {
                _logger.LogError("Counter server dose not matched with the current server name. (counter.server: {}, current server name: {})",
                                counter.Server,
                                _config.CurrentServerName);
                return;
            }
            if (_collectors.Any(collectorItem => collectorItem.IsAssignedBy(counter)))
            {
                _logger.LogError("A same counter is exists. (counter: {})", counter);
                return;
            }
            var provider = _providers.FirstOrDefault(providerItem => providerItem.Name == counter.ProviderName);
            if (provider is null)
            {
                _semaphor.Release();
                throw new InvalidOperationException("No provider match to the counter");
            }
            CounterMetricCollector collector = new CounterMetricCollector(counter, provider, _store);
            _collectors.Add(collector);
            _recurringJobs.Schedule(collector.ToString(),
                                   async (cancellationToken) => await Scan(collector, _store, _notifier, cancellationToken),
                                   TimeSpan.FromMilliseconds(collector.DueTimeInMilliseconds),
                                   TimeSpan.FromMilliseconds(collector.PeriodInMilliseconds));
        }
        private async Task Init(CancellationToken cancellationToken = default)
        {
            try
            {
                var activeCounters = await _store.GetActiveCountersAsync(_config.CurrentServerName, cancellationToken);
                var requiredProviders = activeCounters.Select(activeCounter => activeCounter.ProviderName).Distinct();
                if (_providers.Select(provider => provider.Name).Intersect(requiredProviders).Count() != requiredProviders.Count())
                {
                    _semaphor.Release();
                    throw new InvalidOperationException($"Provided performance metric providers should match with required providers");
                }

                foreach (var counter in activeCounters)
                    StartCounter(counter);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Initializing scan operation failed.");
                _semaphor.Release();
                throw;
            }
        }
        private async Task Scan(CounterMetricCollector collector,
                                IPerformanceStore store,
                                INotifier notifier,
                                CancellationToken cancellationToken)
        {
            try
            {
                var metric = await collector.Collect(cancellationToken);
                await store.SaveMetricAsync(metric, cancellationToken);
                await notifier.Notify(metric, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Scaning performance failed. (exception: {})", ex);
            }
        }
        private void AssertIfNotStrated()
        {
            if (!_isStarted)
            {
                _semaphor.Release();
                throw new InvalidOperationException("Performance scanner does not started.");
            }
        }
        private bool IsRunning() => _collectors.Count > 0;
        private void AssertIfIsRunning()
        {
            if (IsRunning())
            {
                _semaphor.Release();
                throw new InvalidOperationException("Performance sacnner is runnig.");
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            _recurringJobs.Dispose();
            _semaphor.Dispose();
            _disposed = true;
        }
        private const string CLASS_NAME = nameof(PerformanceScanner);
    }
}