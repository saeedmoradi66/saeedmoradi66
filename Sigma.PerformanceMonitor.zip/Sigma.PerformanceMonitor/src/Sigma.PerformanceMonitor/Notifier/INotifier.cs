﻿using System.Threading;
using System.Threading.Tasks;

namespace Sigma.PerformanceMonitor.Notifier
{
    public interface INotifier
    {
        Task Notify(Metric metric, CancellationToken cancellationToken = default);
    }
}