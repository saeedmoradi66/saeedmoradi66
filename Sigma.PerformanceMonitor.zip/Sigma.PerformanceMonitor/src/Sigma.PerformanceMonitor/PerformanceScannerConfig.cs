﻿namespace Sigma.PerformanceMonitor
{
    public class PerformanceScannerConfig
    {
        public string CurrentServerName { set; get; } = default;
    }
}