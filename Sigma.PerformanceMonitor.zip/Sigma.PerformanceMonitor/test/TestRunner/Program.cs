﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Sigma.PerformanceMonitor;
using Sigma.PerformanceMonitor.Notifier;
using Sigma.PerformanceMonitor.Provider;
using Sigma.PerformanceMonitor.Scheduler;
using Sigma.PerformanceMonitor.Store;
using SimpleImplementaions;
using SimpleImplementaions.Fakes;
using System;

namespace TestRunner
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Console.WriteLine($"{DateTime.Now:HH:mm:ss:fff}");


            var services = new ServiceCollection();
            services.AddSingleton<PerformanceScannerConfig>(sp1 => new PerformanceScannerConfig { CurrentServerName = "WEB_1" });
            services.AddSingleton<PerformanceScanner>();
            services.AddScoped<PerformanceMetricProviderConfig>(sp2 =>
            {
                return PerformanceStore.GetWmiProviderConfigAsync("WMI_1").GetAwaiter().GetResult();
            });
            services.AddScoped<IPerformanceMetricProvider, WMIPerformanceMetricProvider>();
            services.AddScoped<IPerformanceStore, PerformanceStore>();
            services.AddSingleton<IRecurringJob, RecurringJob>();
            services.AddSingleton<INotifier, FakeNotifier>();
            services.AddSingleton(typeof(ILogger<>), typeof(FakeLogger<>));

            var appServiceProvider = services.BuildServiceProvider();
            var scope = appServiceProvider.CreateScope();
            var sp = scope.ServiceProvider;

            var scanner = sp.GetRequiredService<PerformanceScanner>();
            scanner.Start().GetAwaiter().GetResult();


            Console.ReadLine();
            scanner.Stop().GetAwaiter().GetResult();
            Console.ReadLine();
        }
    }
}
