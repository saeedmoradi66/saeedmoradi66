﻿using Sigma.PerformanceMonitor.Provider;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions
{
    public class PCCpuPerformanceMetricProvider : PerformanceMetricProvider
    {
        private readonly PerformanceMetricProviderConfig _config;

        public PCCpuPerformanceMetricProvider(PerformanceMetricProviderConfig config) : base(config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(_config));
        }
       
        public override async Task<(DateTime date, Dictionary<string, double> values)> GetMetrics(string[] counterNames, CancellationToken cancellationToken)
        {
            double percent = await Task.Run(() => GetCpuUsage(cancellationToken), cancellationToken);

            var values = new Dictionary<string, double>
            {
                ["PercentProcessorTime"] = percent
            };

            return (DateTime.Now, values);
        }

        private static double GetCpuUsage(CancellationToken cancellationToken)
        {
            using (var counter = new PerformanceCounter("Processor", "% Processor Time", "_Total", true))
            {
                counter.NextValue();
                cancellationToken.ThrowIfCancellationRequested();
                Thread.Sleep(500);
                cancellationToken.ThrowIfCancellationRequested();
                return counter.NextValue();
            }
        }


    }
}