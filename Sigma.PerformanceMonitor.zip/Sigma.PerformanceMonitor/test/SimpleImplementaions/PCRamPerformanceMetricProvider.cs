﻿using Sigma.PerformanceMonitor.Provider;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions
{
    public class PCRamPerformanceMetricProvider : PerformanceMetricProvider
    {
        private readonly PerformanceMetricProviderConfig _config;
        private static readonly PerformanceCounter _committedBytesCounter =
            new PerformanceCounter("Memory", "Committed Bytes", true);
        private static readonly PerformanceCounter _availableMBCounter =
            new PerformanceCounter("Memory", "Available MBytes", true);
      
        public PCRamPerformanceMetricProvider(PerformanceMetricProviderConfig config) : base(config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(_config));
        }
        public override async Task<(DateTime date, Dictionary<string, double> values)> GetMetrics(string[] counterNames, CancellationToken cancellationToken)
        {
            var values = await Task.Run(() => GetRamUsage(), cancellationToken);
            return (DateTime.Now, values);
        }

        private static Dictionary<string, double> GetRamUsage()
        {
            double availableMB = _availableMBCounter.NextValue();
            double committedBytes = _committedBytesCounter.NextValue();
            double committedMB = committedBytes / (1024.0 * 1024.0);

            return new Dictionary<string, double>
            {
                ["AvailableMemoryMB"] = availableMB,
                ["CommittedMemoryMB"] = committedMB
            };
        }


    }
}