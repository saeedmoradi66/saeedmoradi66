﻿using Sigma.PerformanceMonitor.Provider;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions
{
    public class PCDiskPerformanceMetricProvider : PerformanceMetricProvider
    {
        private readonly PerformanceMetricProviderConfig _config;
      
        private static readonly PerformanceCounter _diskReadCounter =
            new PerformanceCounter("PhysicalDisk", "Disk Read Bytes/sec", "0 D:", true);
        private static readonly PerformanceCounter _diskWriteCounter =
            new PerformanceCounter("PhysicalDisk", "Disk Write Bytes/sec", "0 D:", true);
        private static readonly PerformanceCounter _diskIdleCounter =
            new PerformanceCounter("PhysicalDisk", "% Idle Time", "0 D:", true);
        private static readonly PerformanceCounter _diskQueueCounter =
            new PerformanceCounter("PhysicalDisk", "Current Disk Queue Length", "0 D:", true);

        public PCDiskPerformanceMetricProvider(PerformanceMetricProviderConfig config) : base(config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(_config));
        }
        public override async Task<(DateTime date, Dictionary<string, double> values)> GetMetrics(string[] counterNames, CancellationToken cancellationToken)
        {
            var values = await Task.Run(() => GetDiskUsage(), cancellationToken);
            return (DateTime.Now, values);
        }

        private static Dictionary<string, double> GetDiskUsage()
        {
            _diskReadCounter.NextValue();
            _diskWriteCounter.NextValue();
            _diskIdleCounter.NextValue();
            double readBytesPerSec = _diskReadCounter.NextValue();
            double writeBytesPerSec = _diskWriteCounter.NextValue();
            double idlePercent = _diskIdleCounter.NextValue();
            double queueLength = _diskQueueCounter.NextValue();
            double busyPercent = 100.0 - idlePercent;
            return new Dictionary<string, double>
            {
                ["DiskReadBytesPerSec"] = readBytesPerSec,
                ["DiskWriteBytesPerSec"] = writeBytesPerSec,
                ["DiskBusyPercent"] = busyPercent,
                ["DiskQueueLength"] = queueLength
            };
        }

    }
}