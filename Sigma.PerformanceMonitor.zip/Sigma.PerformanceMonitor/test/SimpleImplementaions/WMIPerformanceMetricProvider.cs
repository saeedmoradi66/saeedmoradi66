﻿using Sigma.PerformanceMonitor.Provider;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions
{
    public class WMIPerformanceMetricProvider : PerformanceMetricProvider
    {
        private readonly PerformanceMetricProviderConfig _config;
        public WMIPerformanceMetricProvider(PerformanceMetricProviderConfig config) : base(config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(_config));
        }
        public override async Task<(DateTime date, Dictionary<string, double> values)> GetMetrics(string[] counterNames, CancellationToken cancellationToken)
        {
            ConcurrentDictionary<string, double> metricKeyValues = new ConcurrentDictionary<string, double>();
            List<Task> tasks = new List<Task>();
            tasks.Add(Task.Run(() => GetCpuUsage(metricKeyValues), cancellationToken));
            tasks.Add(Task.Run(() => GetRamUsage(metricKeyValues), cancellationToken));
            tasks.Add(Task.Run(() => GetDiskUsage(metricKeyValues), cancellationToken));
            await Task.WhenAll(tasks);
            return (DateTime.Now, metricKeyValues.ToDictionary(keyValuePair => keyValuePair.Key, keyValuePair => keyValuePair.Value));
        }
        private static Task GetCpuUsage(ConcurrentDictionary<string, double> dic)
        {
            using (var counter = new PerformanceCounter(
                "Processor", "% Processor Time", "_Total", true))
            {
                counter.NextValue(); // warm-up
                System.Threading.Thread.Sleep(500);
                double percent = counter.NextValue();
                dic.AddOrUpdate("PercentProcessorTime", percent, (_, __) => percent);
            }

            return Task.CompletedTask;
        }

        private static Task GetCpuUsage1(ConcurrentDictionary<string, double> dic)
        {
            const string query =
                "SELECT PercentProcessorTime FROM Win32_PerfFormattedData_PerfOS_Processor WHERE Name = '_Total'";

             var searcher = new ManagementObjectSearcher(query);
             var results = searcher.Get();

            var obj = results.Cast<ManagementObject>().FirstOrDefault();
            if (obj == null) return Task.CompletedTask;

            using (obj)
            {
                double percent = Convert.ToDouble(obj["PercentProcessorTime"]);
                dic.AddOrUpdate("PercentProcessorTime", percent, (_, __) => percent);
            }

            return Task.CompletedTask;
        }

        private static async Task GetRamUsage(ConcurrentDictionary<string, double> dic)
        {
            var searcher = new ManagementObjectSearcher("SELECT FreePhysicalMemory, TotalVisibleMemorySize FROM Win32_OperatingSystem");

            foreach (ManagementObject obj in searcher.Get())
            {
                double total = Convert.ToUInt64(obj["TotalVisibleMemorySize"]);
                double free = Convert.ToUInt64(obj["FreePhysicalMemory"]);
                double used = total - free;

                dic.AddOrUpdate("TotalVisibleMemorySize", total, (key, old) => total);
                dic.AddOrUpdate("FreePhysicalMemory", free, (key, old) => free);
                dic.AddOrUpdate("UsedPhysicalMemory", used, (key, old) => used);
                double usedMemoryPercent = used * 100.0 / total;
                dic.AddOrUpdate("UsedMemoryPercentage", usedMemoryPercent, (key, old) => usedMemoryPercent);
                break;
            }
        }
        private static async Task GetDiskUsage(ConcurrentDictionary<string, double> dic)
        {
            var searcher = new ManagementObjectSearcher("SELECT DeviceID, FreeSpace, Size FROM Win32_LogicalDisk WHERE DriveType = 3");

            foreach (ManagementObject disk in searcher.Get())
            {
                double size = Convert.ToUInt64(disk["Size"]);
                double free = Convert.ToUInt64(disk["FreeSpace"]);
                double used = size - free;

                dic.AddOrUpdate("DiskSize", size, (key, old) => size);
                dic.AddOrUpdate("DiskFreeSpace", free, (key, old) => free);
                dic.AddOrUpdate("DiskUsedSpace", used, (key, old) => used);
                double usedMemoryPercent = used * 100.0 / size;
                dic.AddOrUpdate("UsedDiskPercentage", usedMemoryPercent, (key, old) => usedMemoryPercent);
                break;
            }
        }
    }
}