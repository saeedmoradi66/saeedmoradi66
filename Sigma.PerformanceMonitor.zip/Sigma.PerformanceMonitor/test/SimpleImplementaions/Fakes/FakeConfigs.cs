﻿using Sigma.PerformanceMonitor;

namespace SimpleImplementaions.Fakes
{
    public static class FakeConfigs
    {
        public readonly static PerformanceScannerConfig PerformanceScannerConfig 
            = new PerformanceScannerConfig() { CurrentServerName = FakeServers.WEB };
    }
}