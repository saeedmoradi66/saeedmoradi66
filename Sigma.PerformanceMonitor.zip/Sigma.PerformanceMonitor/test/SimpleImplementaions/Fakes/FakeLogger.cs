﻿using Microsoft.Extensions.Logging;
using System;

namespace SimpleImplementaions.Fakes
{
    public class FakeLogger<T> : ILogger<T>
    {
        public bool IsEnabled(LogLevel logLevel) => true;
        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            Console.WriteLine($"{logLevel} {state} {exception} {DateTime.Now:HH:mm:ss:fff}");
        }
        IDisposable ILogger.BeginScope<TState>(TState state)
        {
            throw new NotImplementedException();
        }
    }
}