﻿using Sigma.PerformanceMonitor;
using Sigma.PerformanceMonitor.Notifier;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions.Fakes
{
    public class FakeNotifier : INotifier
    {
        public Task Notify(Metric metric, CancellationToken cancellationToken = default)
        {
            if (metric.Value > metric.Counter.MetricValueThreshold)
                Console.WriteLine($"Notify *** Threshold exceeded => {metric}");
            //else
            //    Console.WriteLine($"Notify => {metric}");
            return Task.CompletedTask;
        }
    }
}