﻿using Sigma.PerformanceMonitor;
using Sigma.PerformanceMonitor.Store;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions.Fakes
{
    public class FakePerformanceStore : IPerformanceStore
    {
        public Task<Counter[]> GetActiveCountersAsync(string serverName, CancellationToken cancellationToken = default)
        {
            Console.WriteLine("Store => GetActiveCountersAsync");
            return Task.FromResult(FakeCounters.Counters.Where(counter => counter.Server == serverName).ToArray());
        }
        public Task<Counter> FetchActiveCounterAsync(string serverName, string counterName, string providerName, CancellationToken cancellationToken = default)
        {
            Console.WriteLine("Store => GetActiveCountersAsync");
            var counter = FakeCounters.Counters
                                      .FirstOrDefault(counterItem => counterItem.Server == serverName
                                                                  && counterItem.Name == counterName
                                                                  && counterItem.ProviderName == counterItem.ProviderName);
            return Task.FromResult(counter);
        }
        public Task SaveMetricAsync(Metric metric, CancellationToken cancellationToken = default)
        {
            Console.WriteLine($"Store => SaveMetricAsync => {metric}");
            return Task.CompletedTask;
        }
    }
}