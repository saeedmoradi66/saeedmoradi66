﻿using Sigma.PerformanceMonitor.Provider;
using System.Collections.Generic;

namespace SimpleImplementaions.Fakes
{
    public static class FakePerformanceMetricProviders
    {
        public const string FIRST_PROVIDER = nameof(FIRST_PROVIDER);
        public const string SECOND_PROVIDER = nameof(SECOND_PROVIDER);
        public readonly static IPerformanceMetricProvider First = new FakePerformanceMetricProvider(new PerformanceMetricProviderConfig
        {
            Name = FIRST_PROVIDER,
            CounterMappings = new Dictionary<string, string> {
            { FakeCounters.COUNTER_ONE, FakeCounters.COUNTER_FIRST_PROVIDER_ONE },
            { FakeCounters.COUNTER_TWO, FakeCounters.COUNTER_FIRST_PROVIDER_TWO },
            { FakeCounters.COUNTER_THREE, FakeCounters.COUNTER_FIRST_PROVIDER_THREE },
        },
            CacheExpirationInMiliseconds = 10,
        });
        public readonly static IPerformanceMetricProvider Second = new FakePerformanceMetricProvider(new PerformanceMetricProviderConfig
        {
            Name = SECOND_PROVIDER,
            CounterMappings = new Dictionary<string, string> {
            { FakeCounters.COUNTER_ONE, FakeCounters.COUNTER_SECOND_PROVIDER_ONE },
            { FakeCounters.COUNTER_TWO, FakeCounters.COUNTER_SECOND_PROVIDER_TWO },
        },
            CacheExpirationInMiliseconds = 10,
        });
    }
}