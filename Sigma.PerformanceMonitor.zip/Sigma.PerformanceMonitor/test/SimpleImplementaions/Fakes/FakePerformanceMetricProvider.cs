﻿using Sigma.PerformanceMonitor.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions.Fakes
{
    public class FakePerformanceMetricProvider : PerformanceMetricProvider
    {
        private readonly PerformanceMetricProviderConfig _config;
        private readonly Random _random = new Random();
        public FakePerformanceMetricProvider(PerformanceMetricProviderConfig config) : base(config)
        {
            _config = config;
        }
        public override Task<(DateTime date, Dictionary<string, double> values)> GetMetrics(string[] counterNames, CancellationToken cancellationToken)
        {
            var metricValues = _config.CounterMappings.Values.Select(counter => new KeyValuePair<string, double>(counter, _random.NextDouble()));
            Dictionary<string, double> values = new Dictionary<string, double>();
            foreach (var metric in metricValues)
                values.Add(metric.Key, metric.Value);
            return Task.FromResult((DateTime.Now, values));
        }
    }
}