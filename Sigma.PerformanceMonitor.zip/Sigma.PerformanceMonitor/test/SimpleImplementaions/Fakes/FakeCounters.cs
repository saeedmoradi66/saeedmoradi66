﻿using Sigma.PerformanceMonitor;

namespace SimpleImplementaions.Fakes
{
    public static class FakeCounters
    {
        public const string COUNTER_ONE = nameof(COUNTER_ONE);
        public const string COUNTER_TWO = nameof(COUNTER_TWO);
        public const string COUNTER_THREE = nameof(COUNTER_THREE);
        public const string COUNTER_FIRST_PROVIDER_ONE = nameof(COUNTER_FIRST_PROVIDER_ONE);
        public const string COUNTER_FIRST_PROVIDER_TWO = nameof(COUNTER_FIRST_PROVIDER_TWO);
        public const string COUNTER_FIRST_PROVIDER_THREE = nameof(COUNTER_FIRST_PROVIDER_THREE);
        public const string COUNTER_SECOND_PROVIDER_ONE = nameof(COUNTER_SECOND_PROVIDER_ONE);
        public const string COUNTER_SECOND_PROVIDER_TWO = nameof(COUNTER_SECOND_PROVIDER_TWO);
        public readonly static Counter[] Counters = new Counter[] {
            CreateCounter(COUNTER_ONE, FakePerformanceMetricProviders.FIRST_PROVIDER, FakeServers.WEB, 5_000, 7_000, .8, true, true),
            CreateCounter(COUNTER_TWO, FakePerformanceMetricProviders.FIRST_PROVIDER, FakeServers.API_GATEWAY, 2_000, 3_000, .8, true, true),
            CreateCounter(COUNTER_THREE, FakePerformanceMetricProviders.FIRST_PROVIDER, FakeServers.API_GATEWAY, 1_000, 10_000, .8, true, true),
            CreateCounter(COUNTER_ONE, FakePerformanceMetricProviders.SECOND_PROVIDER, FakeServers.API_GATEWAY, 5_000, 10_000, .8, true, true),
            CreateCounter(COUNTER_TWO, FakePerformanceMetricProviders.SECOND_PROVIDER, FakeServers.API_GATEWAY, 1_000, 10_000, .5, true, true),
        };

        private static Counter CreateCounter(string name, string providerName, string server, int dueTime, int period, double threshold, bool emailEnabled, bool smsEnabled)
            => new Counter()
            {
                Name = name,
                ProviderName = providerName,
                Server = server,
                DueTimeInMilliseconds = dueTime,
                PeriodInMilliseconds = period,
                MetricValueThreshold = threshold,
                IsEmailNotificationEnabled = emailEnabled,
                IsSMSNotificationEnabled = smsEnabled,
            };
    }
}