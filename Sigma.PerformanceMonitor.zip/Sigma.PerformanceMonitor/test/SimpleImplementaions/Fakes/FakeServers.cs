﻿namespace SimpleImplementaions.Fakes
{
    public static class FakeServers
    {
        public const string WEB = nameof(WEB);
        public const string API_GATEWAY = nameof(API_GATEWAY);
    }
}