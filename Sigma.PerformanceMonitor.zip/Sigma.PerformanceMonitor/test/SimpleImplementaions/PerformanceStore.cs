﻿using Newtonsoft.Json;
using Sigma.PerformanceMonitor;
using Sigma.PerformanceMonitor.Provider;
using Sigma.PerformanceMonitor.Store;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleImplementaions
{
    public class PerformanceStore : IPerformanceStore
    {
        //private const string CONNECTION_STRING = @".\SQL2022";
        private const string CONNECTION_STRING = @"Data Source=.;Initial Catalog=PerformanceMonitor;user=sa;password=qaz!@#QAZ123;TrustServerCertificate=True;";
        public async Task<Counter> FetchActiveCounterAsync(string serverName, string counterName, string providerName, CancellationToken cancellationToken = default)
        {
            Counter counter = default;
            string sql = $@"
SELECT * FROM [dbo].[Counter]
WHERE [Server] = N'{serverName}'
  AND [Name] = N'{counterName}'
  AND [ProviderName] = N'{providerName}'
  AND [Enabled] = 1
";
            SqlCommand command = new SqlCommand(sql, new SqlConnection(CONNECTION_STRING));
            try
            {
                await command.Connection.OpenAsync(cancellationToken);
                var reader = await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    var name = reader["Name"].ToString();
                    var server = reader["Server"].ToString();
                    var provider = reader["ProviderName"].ToString();
                    var dueTime = Convert.ToInt32(reader["DueTimeInMillisecoinds"]);
                    var period = Convert.ToInt32(reader["PeriodInMilliseconds"]);
                    var threshold = Convert.ToDouble(reader["MetricValueThreshold"]);
                    var isEmailEnabled = Convert.ToBoolean(reader["IsEmailNotificationEnabled"]);
                    var isSmsEnabled = Convert.ToBoolean(reader["IsSMSNotificationEnabled"]);
                    counter = new Counter
                    {
                        Name = name,
                        Server = server,
                        ProviderName = provider,
                        DueTimeInMilliseconds = dueTime,
                        PeriodInMilliseconds = period,
                        MetricValueThreshold = threshold,
                        IsEmailNotificationEnabled = isEmailEnabled,
                        IsSMSNotificationEnabled = isSmsEnabled,
                    };
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (command.Connection.State.HasFlag(System.Data.ConnectionState.Connecting)
                 || command.Connection.State.HasFlag(System.Data.ConnectionState.Open))
                    command.Connection.Close();
                command.Dispose();
            }
            return counter;
        }
        public async Task<Counter[]> GetActiveCountersAsync(string serverName, CancellationToken cancellationToken = default)
        {
            List<Counter> counters = new List<Counter>();
            string sql = $@"
SELECT * FROM [dbo].[Counter]
WHERE  [Server] = N'{serverName}'
  AND [Enabled] = 1
";
            SqlCommand command = new SqlCommand(sql, new SqlConnection(CONNECTION_STRING));
            try
            {
                await command.Connection.OpenAsync(cancellationToken);
                var reader = await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    var name = reader["Name"].ToString();
                    var server = reader["Server"].ToString();
                    var provider = reader["ProviderName"].ToString();
                    var dueTime = Convert.ToInt32(reader["DueTimeInMilliseconds"]);
                    var period = Convert.ToInt32(reader["PeriodInMilliseconds"]);
                    var threshold = Convert.ToDouble(reader["MetricValueThreshold"]);
                    var isEmailEnabled = Convert.ToBoolean(reader["IsEmailNotificationEnabled"]);
                    var isSmsEnabled = Convert.ToBoolean(reader["IsSMSNotificationEnabled"]);
                    counters.Add(new Counter
                    {
                        Name = name,
                        Server = server,
                        ProviderName = provider,
                        DueTimeInMilliseconds = dueTime,
                        PeriodInMilliseconds = period,
                        MetricValueThreshold = threshold,
                        IsEmailNotificationEnabled = isEmailEnabled,
                        IsSMSNotificationEnabled = isSmsEnabled,
                    });
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (command.Connection.State.HasFlag(System.Data.ConnectionState.Connecting)
                 || command.Connection.State.HasFlag(System.Data.ConnectionState.Open))
                    command.Connection.Close();
                command.Dispose();
            }
            return counters.ToArray();
        }
        public async Task SaveMetricAsync(Metric metric, CancellationToken cancellationToken = default)
        {
            string sql = $@"
INSERT INTO [dbo].[Metric] ([Counter], [Server], [Provider], [Value], [Date], [Threshold])
VALUES (N'{metric.Counter.Name}', N'{metric.Counter.Server}', N'{metric.Counter.ProviderName}', {metric.Value}, '{metric.Date}', {metric.Counter.MetricValueThreshold});
";
            SqlCommand command = new SqlCommand(sql, new SqlConnection(CONNECTION_STRING));
            try
            {
                await command.Connection.OpenAsync(cancellationToken);
                await command.ExecuteNonQueryAsync(cancellationToken);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (command.Connection.State.HasFlag(System.Data.ConnectionState.Connecting)
                 || command.Connection.State.HasFlag(System.Data.ConnectionState.Open))
                    command.Connection.Close();
                command.Dispose();
            }
        }
        public static Task<PerformanceMetricProviderConfig> GetWmiProviderConfigAsync(string providerName, CancellationToken cancellationToken = default)
            => GetProviderConfigAsync(providerName, cancellationToken);
        public static async Task<PerformanceMetricProviderConfig> GetProviderConfigAsync(string providerName, CancellationToken cancellationToken = default)
        {
            PerformanceMetricProviderConfig config = default;
            string sql = $@"
SELECT * FROM [dbo].[PerformanceMetricProviderConfig]
WHERE  [Name] = N'{providerName}'
";
            SqlCommand command = new SqlCommand(sql, new SqlConnection(CONNECTION_STRING));
            try
            {
                await command.Connection.OpenAsync(cancellationToken);
                var reader = await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    var name = reader["Name"].ToString();
                    var mappings = reader["CounterMappings"].ToString();
                    var cacheExpiration = Convert.ToInt32(reader["CacheExpirationInMiliseconds"]);
                    var dic = JsonConvert.DeserializeObject<Dictionary<string, string>>(mappings);
                    config = new PerformanceMetricProviderConfig
                    {
                        Name = name,
                        CounterMappings = dic,
                        CacheExpirationInMiliseconds = cacheExpiration,
                    };
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (command.Connection.State.HasFlag(System.Data.ConnectionState.Connecting)
                 || command.Connection.State.HasFlag(System.Data.ConnectionState.Open))
                    command.Connection.Close();
                command.Dispose();
            }
            return config;
        }
    }
}
