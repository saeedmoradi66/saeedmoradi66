﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Sigma.PerformanceMonitor;
using Sigma.PerformanceMonitor.Notifier;
using Sigma.PerformanceMonitor.Provider;
using Sigma.PerformanceMonitor.Scheduler;
using Sigma.PerformanceMonitor.Store;
using SimpleImplementaions;
using SimpleImplementaions.Fakes;
using System;
using System.Collections.Concurrent;

namespace WebTestRunner
{
    public class Global : System.Web.HttpApplication
    {
        private const string CPU_PROVIDER_NAME = "PC_CPU";
        private const string RAM_PROVIDER_NAME = "PC_RAM";
        private const string DISK_PROVIDER_NAME = "PC_DISK";

        private static readonly ConcurrentDictionary<string, PerformanceMetricProviderConfig> _providerConfigs
            = new ConcurrentDictionary<string, PerformanceMetricProviderConfig>();

        IServiceScope scope;
        PerformanceScanner scanner;
        protected void Application_Start(object sender, EventArgs e)
        {
            var services = new ServiceCollection();
            services.AddSingleton<PerformanceScannerConfig>(sp1 => new PerformanceScannerConfig { CurrentServerName = "WEB_1" });
            services.AddSingleton<PerformanceScanner>();
            services.AddScoped<IPerformanceMetricProvider>(sp2 =>
                new PCCpuPerformanceMetricProvider(GetProviderConfig(CPU_PROVIDER_NAME)));
            services.AddScoped<IPerformanceMetricProvider>(sp3 =>
                new PCRamPerformanceMetricProvider(GetProviderConfig(RAM_PROVIDER_NAME)));
            services.AddScoped<IPerformanceMetricProvider>(sp4 =>
                new PCDiskPerformanceMetricProvider(GetProviderConfig(DISK_PROVIDER_NAME)));
            services.AddScoped<IPerformanceStore, PerformanceStore>();
            services.AddSingleton<IRecurringJob, RecurringJob>();
            services.AddSingleton<INotifier, FakeNotifier>();
            services.AddSingleton(typeof(ILogger<>), typeof(FakeLogger<>));


            var appServiceProvider = services.BuildServiceProvider();
            scope = appServiceProvider.CreateScope();
            var sp = scope.ServiceProvider;

            scanner = sp.GetRequiredService<PerformanceScanner>();
            scanner.Start().GetAwaiter().GetResult();
        }
        private static PerformanceMetricProviderConfig GetProviderConfig(string providerName)
        {
            return _providerConfigs.GetOrAdd(providerName, name =>
            {
                var config = PerformanceStore.GetProviderConfigAsync(name).GetAwaiter().GetResult();
                if (config is null)
                    throw new InvalidOperationException($"No provider config found in the store. (providerName: {name})");
                if (config.CounterMappings is null)
                    throw new InvalidOperationException($"Provider config has no counter mappings. (providerName: {name})");
                return config;
            });
        }
        protected void Application_End(object sender, EventArgs e)
        {
            if (scanner != null)
                scanner.Stop().GetAwaiter().GetResult();
        }
        protected void Session_Start(object sender, EventArgs e) { }
        protected void Application_BeginRequest(object sender, EventArgs e) { }
        protected void Application_AuthenticateRequest(object sender, EventArgs e) { }
        protected void Application_Error(object sender, EventArgs e) { }
        protected void Session_End(object sender, EventArgs e) { }
    }
}
