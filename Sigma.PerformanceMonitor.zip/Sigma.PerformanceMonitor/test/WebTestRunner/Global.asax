﻿<%@ Application Codebehind="Global.asax.cs" Inherits="WebTestRunner.Global" Language="C#" %>
